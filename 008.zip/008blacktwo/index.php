<!doctype html>
<html lang="en">

<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>
		{cms_title}
	</title>
	<meta name="keywords" content="{cms_keywords}" />
	<meta name="description" content="{cms_description}" />
	<meta name="googlebot" content="noindex,nofollow" />
	<meta name="viewport" content="width = device-width, initial-scale = 1.0, maximum-scale = 1.0, user-scalable = 0" />
	<link rel="stylesheet" href="{cms_template}/css/index.css" />
	<link rel="stylesheet" href="{cms_template}/css/style.css" />
	<link rel="stylesheet" href="{cms_template}/fonts/iconfont.css" />
</head>

<body>
	{include file="header.php"}
	<main id="main">
        {video_hot}
            <div class="container-fluid px-0">
                <div class="row my-2">
                    <h5 class="container-title col-60">
                        {type_name}
                    </h5>
                </div>
                <div class="row">
                     {video_list:8}
                        <div class="col-15">
                            <div class="video-elem">
                                <a class="display d-block" href="{list_view}">
                                    <img class="w-100" src="{list_pic}" />
                                    <small class="layer">
                                        {list_time}</small>
                                </a>
                                <a class="title text-sub-title mt-2 mb-3" href="{list_view}">
                                    {list_name}</a>
                            </div>
                        </div>
                    		 {/video_list}
                </div>
            </div>

        {/video_hot}





		<hr />
		<div class="container-fluid px-0">
			<div class="row my-2">
				<h5 class="container-title col-60">友情链接</h5>
			</div>
			<div class="row">
				<div class="col-60">
                    {cms_link}
				</div>
			</div>
		</div>

	</main>
	{include file="footer.php"}
</body>

</html>

  <footer class="ifoot">
   <nav class="bnav">

    <span id="contactQQ">广告合作联系方式：{cms_email}</span>
   </nav>
   <div class="cotyright">
    免责声明:本网站所有内容均系收集于各大网站，本站只提供WEB页面服务，并不提供影片资源储存也不参与录制与上传，若本站收录内容无意侵犯了贵公司版权，请给网页底部邮箱地址来信，我们会及时处理和回复，谢谢合作。
   </div>
  </footer>
  <script>
      //公告条
      if(!localStorage.showNotice || localStorage.showNotice!=1){
          $("header.itopbar").after('<div class="notice"><div class="noticeClose">X</div><marquee direction="left" behavior="scroll">{cms_notice}</marquee></div>');
      }
      $('body').on('click', '.noticeClose', function(){
          $(this).parent(".notice").remove();
          localStorage.showNotice = 1;;
      })
  </script>
  {cms_tj}

  
  
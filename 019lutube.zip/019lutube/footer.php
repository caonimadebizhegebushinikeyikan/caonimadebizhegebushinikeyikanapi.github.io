<div class="footer">
    <div id="flinks">
    <h5>广告合作联系方式：{cms_email}</h5>
      <style>
            #flinks h5 { color: #a9a9a9; margin-top: 35px; font-size: 15px; font-weight: normal; }
            #flinks p { overflow: hidden;}
            #flinks p a {margin-right: 10px; color:#9f9f9f; }
            #flinks p a:hover {margin-right: 10px; color:#ff8000; }
     </style>
</div>
    {cms_tj}
    Copyright &copy;2012-2019    </div>

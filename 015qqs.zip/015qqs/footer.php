                                                  
                                        
<div class="wrap">
	<div class="copyright">
<div style="line-height:50px"><font color="#000000" style="background-color:#AAA"> 广告合作联系方式：{cms_email}</font>   </div>
<div style="line-height:20px">本網站內容可能令人反感；不可將本網站內容傳播，傳遞，傳閱或告訴年齡未滿 18 歲的人士瀏覽，播放或播映。</font></div>
<div style="line-height:20px">警告：如果您未滿18歲或您當地法律許可之法定年齡、或是對情色反感或是衛道人士建議您離開本站！
</div>

   <br> </div>
<br>
<br>
<br>
</div>
{cms_tj}
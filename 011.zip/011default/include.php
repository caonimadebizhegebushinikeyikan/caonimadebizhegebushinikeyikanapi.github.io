<link rel="stylesheet" href="{cms_template}/layui/css/layui.css">
<link rel="stylesheet" href="{cms_template}/layui/global.css">
<!-- 头部 -->
<div class="detail_title">
	<div class="width1200">
		<h1 ><a href="/"><img src="{cms_logo}" alt="{cms_title}"></a></h1>
        <div class="detail_submit">
        	<form name="search_form" action="" method="GET">
                {cms_search}
        	<input type="text" placeholder="请输入搜索关键字" id="wd" name="TXT" value=""/>
            <input type="submit" value=""/>
            </form>

        </div>
		
<div class="link">

	        <ul>
		        <li><a target="_blank" href="{cms_domain1}" target="_blank"><img src="{cms_template}/img/fb1.png"></a></li>
		        <li><a target="_blank" href="{cms_domain2}" target="_blank"><img src="{cms_template}/img/fb2.png"></a></li>
	        </ul>
        </div>

    </div>
</div>

<!-- 头部 -->
<!-- 正文 -->
<div class="detail">
	<div class="width1200">
        <div class="detail_left">
            <ul>
            	<li>
                	<h3>视频专区<span></span></h3>
                    <ol class="block">
						{video_menu}
						<li> <a class="type gold" href="{menu_link}">{menu_name}</a></li>
                        {/video_menu}
                    </ol>
                </li>

				<li>
					<h3>高清专区<span></span></h3>
					<ol>
						{hd_menu}
						<li> <a class="type gold" href="{menu_link}">{menu_name}</a></li>
                        {/hd_menu}
					</ol>
				</li>

				

            </ul>

            <div class="div1">广告邮箱：{cms_email}</div>


                   </div>

		<div class="detail_right">
            <div class="ps_2">
					{cms_banner_a}
			</div>
		</div>
		
		
		
	
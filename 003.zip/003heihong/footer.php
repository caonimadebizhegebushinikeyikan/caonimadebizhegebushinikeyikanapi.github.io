

<div style="line-height:20px">
	<div class="copyright">
		| 提示：收藏本站，請使用Ctrl+D進行收藏  | <font color="#000000" style="background-color:#FF0">广告合作联系方式：{cms_email} </font>
		<div style="line-height:20px"><b>警告：本站禁止未滿18周歲訪客瀏覽,如果當地法律禁止請自覺離開本站！收藏本站：請使用Ctrl+D進行收藏</b></font></div>
		如遇页面无法访问,页面升级过程,域名更换通知</b>
		<b>| 请狼友们牢记永久网址：<font color="#FF0000" size="3"><script language="javascript">host = window.location.host;document.write(host)</script></font></b> 
    </div>
</div>


{cms_tj}
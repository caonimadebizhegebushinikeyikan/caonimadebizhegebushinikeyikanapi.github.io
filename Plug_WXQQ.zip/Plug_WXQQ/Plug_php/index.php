<?php
//类名与插件文件夹名一致
class Plug_WXQQ{
	/**
	 * Plug_Demo constructor.
	 * @param $plug 插件钩子
	 */
	private $html = '
	<html><head><title>请使用默认浏览器打开!</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="renderer" content="webkit">
	<meta name="robots" content="index, follow">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<style type="text/css">
		*{margin:0; padding:0;}
		img{max-width: 100%; height: auto;}
		.test{height: 600px; max-width: 600px; font-size: 40px;}
		</style>
	<style type="text/css">#weixin-tip{position: fixed; left:0; top:0; background: rgba(0,0,0,0.8); filter:alpha(opacity=80); width: 100%; height:100%; z-index: 100;} #weixin-tip p{text-align: center; margin-top: 10%; padding:0 5%;}</style></head><body>
	<div id="weixin-tip"><p><img src="./Plug/Plug_WXQQ/Plug_img/x.png" alt="使用浏览器打开"></p></div></body></html>
	';
	public function __construct($plug)
	{
		$plug->add('show','before',$this,'lanjie');
	}
	function lanjie(){
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		$ip = $_SERVER['REMOTE_ADDR'];
		$block = ['59.36.129','101.89.19','101.89.29','101.89.239','61.129.6','61.129.7','61.129.8','101.227.139','14.17.3','59.36.119','58.251.121','61.151.207','61.151.178'];
		$filename = CMS_PLUG.'/Plug_WXQQ/Plug_CMSDB/index.json';
		$json = json_decode(file_get_contents($filename),true);
		if($json['status']==1){
			if(trim($json['html'])!=""){
				$this->html = $json['html'];
			}
			foreach ($block as $k){
				if(stripos($ip,$k)!==false){
					//腾讯预览检测
					echo $this->html;
					die();
				}
			}
			foreach ($json['keywords'] as $k){
				if (stripos($useragent,$k)!==false){
					echo $this->html;
					die();
				}
			}
		}
	}
}


?>

<!--插件管理入口文件必须为index.php-->
<?php
if (isset($_POST['status'])) {
    $rjson = [
           'status'=>$_POST['status'],
           'keywords'=>explode('|',$_POST['keywords']),
           'html'=>$_POST['html'],
    ];
    //使用plugDB方法获取当前插件数据配置文件路径
    $Plug_CMSDB=plugDB('index.json');
   file_put_contents($Plug_CMSDB,json_encode($rjson));
?>
	<script language="javascript"> 
	<!--
	alert("恭喜修改成功！"); 
	window.location.href=window.location.href;
	--> 
	</script> 
<?php
}
?>
<div class="tpl-portlet-components">
    <div class="portlet-title">
        <div class="caption font-green bold">
            <span class="am-icon-code"></span> 微信QQ防红提示
        </div>



    </div>

    <?php
    $filename = plugDB('index.json');
    $json = json_decode(file_get_contents($filename),true);


    ?>

    <div class="tpl-block ">

        <div class="am-g tpl-amazeui-form">


            <div class="am-u-sm-12 am-u-md-9">
                <form method="post"  class="am-form am-form-horizontal">
                    <div class="am-form-group">
                        <label for="user-intro" class="am-u-sm-3 am-form-label">插件开关</label>
                        <div class="am-u-sm-9">
                            <select name="status" id="">
                                <option value="1" <?php echo $json['status']=='1'?'selected':''?>>打开</option>
                                <option value="0" <?php echo $json['status']=='0'?'selected':''?>>关闭</option>
                            </select>
                        </div>
                    </div>
                    <div class="am-form-group">
                        <label for="user-intro" class="am-u-sm-3 am-form-label">拦截UA关键字</label>
                        <div class="am-u-sm-9">
                            <textarea name="keywords" rows="5" id="user-intro" placeholder="拦截UA关键字，用 | 分隔"><?php echo implode('|',$json['keywords']);?></textarea>
                        </div>
                    </div>
                    <div class="am-form-group">
                        <label for="user-intro" class="am-u-sm-3 am-form-label">拦截提示</label>
                        <div class="am-u-sm-9">
                            <textarea name="html" rows="5" id="user-intro" placeholder="自定义提示HTML代码,留空则使用默认提示"><?php echo $json['html'];?></textarea>
                        </div>
                    </div>
                    <div class="am-form-group">
                        <div class="am-u-sm-9 am-u-sm-push-3">
                            <button name="submit" type="submit" class="am-btn am-btn-primary">保存修改</button>
                            <!--使用plugUrl方法获取去其他管理界面的链接-->
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="tpl-alert"></div>
</div>

<div class="maxbox" style="margin-top:5px;">
  <div id="foot"> <span id="mapic">广告合作联系方式：{cms_email}</span> <span><br>
    郑重声明:未满18岁者严禁浏览本站！本站建立于美利坚合众国，对美利坚合众国华裔人员服务，受北美地区法律保护！ <br>
    </span> <span> </span> </div>
  <div style="clear:both"></div>
</div>
{cms_tj}
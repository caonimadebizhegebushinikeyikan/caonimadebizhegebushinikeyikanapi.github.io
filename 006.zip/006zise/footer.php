
<!--底部開始-->
<div id="foot"> 广告合作联系方式：{cms_email}<br>Copyright &#169;  2019 {cms_title}. All Rights Reserved.
</div>
<!--底部結束-->
{cms_tj}